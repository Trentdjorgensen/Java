## Getting Started

Project Name: Hotel Management System
Project Description

The Hotel Management System is a console-based Java application designed to help manage hotel room operations.
It provides functionality for adding rooms, viewing room availability, booking rooms, releasing rooms, and deleting rooms.
The system uses SQLite to store room information persistently and loads all saved rooms each time the program starts.

Project Tasks

Task 1: Set up the development environment
Install Java Development Kit (JDK)
Configure IDE (VS Code, IntelliJ, or Eclipse)
Ensure SQLite JDBC driver is available
Task 2: Design the application
Plan the class structure (Hotel, Room, Room types, DatabaseHandler)
Design how room operations will be handled in memory and in the database
Task 3: Implement the room classes
Create abstract Room class
Implement RoomOperations interface
Develop SingleRoom, DoubleRoom, and SuiteRoom subclasses
Task 4: Implement backend logic
Build Hotel class for managing rooms in memory
Add methods for adding, viewing, booking, releasing, and deleting rooms
Task 5: Implement database functionality
Set up SQLite database (hotel.db)
Create DatabaseHandler class for:
Creating the rooms table
Inserting rooms
Updating room status
Deleting rooms
Loading saved rooms at startup
Task 6: Develop user interface
Build a console-based menu in App.java
Handle user choices and input validation
Connect UI actions to Hotel and DatabaseHandler methods
Task 7: Test the application
Add and view rooms
Test booking and releasing rooms
Verify database persistence
Debug and correct issues
Task 8: Document the project
Write a detailed README
Explain class purposes and project workflow

Project Skills Learned
Object-oriented programming (OOP)
Abstraction, inheritance, and polymorphism
Working with interfaces
Database management using SQLite
Using JDBC for database connections
Console-based user interface development
Debugging and testing Java applications
Version control with Git and GitHub

Language Used
Java: Main programming language
SQL (SQLite): For storing room data persistently

Development Process Used
Object-Oriented Design: Structuring the program using classes, abstraction, and interfaces
Modular Development: Splitting the system into components (Hotel, DatabaseHandler, Room types)
Iterative Development: Building and testing features step-by-step

Notes
Ensure the SQLite JDBC driver is included in the classpath before running.
The database file (hotel.db) is created automatically.
Running the program will automatically:
Create the rooms table
Load any previously saved rooms

Link to Project
(Add your GitHub repository link here)

License
This project is licensed under the GNU License – see the
LICENSE file for details.