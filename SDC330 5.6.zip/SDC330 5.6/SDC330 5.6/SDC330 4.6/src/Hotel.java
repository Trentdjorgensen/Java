/*Trent Jorgensen
SDC330 5.6
12/10/2025
*/

import java.util.ArrayList;
import java.util.List;

public class Hotel {
    // The name of the hotel (e.g., "The Oasis Hotel")
    private final String name;

    // A list to store all Room objects belonging to this hotel
    private List<Room> rooms;

    // Constructor: initializes the hotel with a name and an empty list of rooms
    public Hotel(String name) {
        this.name = name;
        this.rooms = new ArrayList<>();
    }

    // Allows replacing the current list of rooms with another list (e.g., loaded from a database)
    public void setRooms(List<Room> rooms) {
        this.rooms = rooms;
    }

    // Adds a new room to the hotel and prints confirmation
    public void addRoom(Room room) {
        rooms.add(room);
        System.out.println("Room " + room.getRoomNumber() + " added.");
    }

    // Returns the list of all rooms in the hotel
    public List<Room> getRooms() {
        return rooms;
    }

    // Displays details of all rooms in the hotel
    public void viewRooms() {
        if (rooms.isEmpty()) {
            // If no rooms exist, print a message
            System.out.println("No rooms available.");
        } else {
            // Otherwise, loop through each room and print its details
            for (Room r : rooms) {
                System.out.println(r.getDetails());
            }
        }
    }

    // Deletes a room from the hotel based on its room number
    public void deleteRoom(int roomNum) {
        // removeIf will remove any room whose number matches roomNum
        rooms.removeIf(r -> r.getRoomNumber() == roomNum);
        System.out.println("Room " + roomNum + " deleted.");
    }

    // Books a room (changes its status to Occupied) based on room number
    public void bookRoom(int roomNum) {
        for (Room r : rooms) {
            if (r.getRoomNumber() == roomNum) {
                r.bookRoom(); // calls the Room's bookRoom() method
                System.out.println("Room " + roomNum + " booked.");
                return; // exit once the room is found and booked
            }
        }
        // If no room matches the given number
        System.out.println("Room not found.");
    }

    // Releases a room (changes its status back to Available) based on room number
    public void releaseRoom(int roomNum) {
        for (Room r : rooms) {
            if (r.getRoomNumber() == roomNum) {
                r.releaseRoom(); // calls the Room's releaseRoom() method
                System.out.println("Room " + roomNum + " released.");
                return; // exit once the room is found and released
            }
        }
        // If no room matches the given number
        System.out.println("Room not found.");
    }
}

