/*Trent Jorgensen
SDC330 5.6
12/10/2025
*/

// DoubleRoom class: represents a specific type of room (Double) in the hotel.
// It extends the abstract Room class and provides concrete implementations
// for booking and releasing the room.
public class DoubleRoom extends Room {

    // Constructor: initializes a DoubleRoom with its room number, status, and price.
    // The "type" is hardcoded as "Double" since this class always represents double rooms.
    public DoubleRoom(int roomNum, String status, double price) {
        // Calls the constructor of the parent class (Room) to set up the fields.
        super(roomNum, "Double", status, price);
    }

    // Overrides the abstract method from RoomOperations.
    // When a room is booked, its status is set to "Occupied".
    @Override
    public void bookRoom() { 
        setStatus("Occupied"); 
    }

    // Overrides the abstract method from RoomOperations.
    // When a room is released, its status is set back to "Available".
    @Override
    public void releaseRoom() { 
        setStatus("Available"); 
    }
}

