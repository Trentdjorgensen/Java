/*Trent Jorgensen
SDC330 5.6
12/10/2025
*/

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHandler {

    // Establishes a connection to the SQLite database "hotel.db"
    // If the file does not exist, SQLite will create it automatically.
    private Connection connect() {
        try {
            return DriverManager.getConnection("jdbc:sqlite:hotel.db");
        } catch (SQLException e) {
            // Prints the error stack trace if connection fails
            e.printStackTrace();
            return null;
        }
    }

    // Creates the "rooms" table if it does not already exist
    public void createTable() {
        // SQL statement to create a table with columns: roomNum, type, status, price
        String sql = "CREATE TABLE IF NOT EXISTS rooms (" +
                     "roomNum INTEGER PRIMARY KEY, " + // unique room number
                     "type TEXT, " +                   // room type (Single/Double/Suite)
                     "status TEXT, " +                 // room status (Available/Occupied)
                     "price REAL)";                    // room price

        // Try-with-resources ensures the connection and statement are closed automatically
        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute(sql); // Executes the SQL statement
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Inserts a new room record into the "rooms" table
    public void insertRoom(int roomNum, String type, String status, double price) {
        String sql = "INSERT INTO rooms(roomNum, type, status, price) VALUES(?,?,?,?)";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            // Set values for the placeholders (?) in the SQL statement
            pstmt.setInt(1, roomNum);
            pstmt.setString(2, type);
            pstmt.setString(3, status);
            pstmt.setDouble(4, price);

            // Execute the insert operation
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Updates the status of a room (e.g., Available -> Occupied)
    public void updateRoom(int roomNum, String status) {
        String sql = "UPDATE rooms SET status=? WHERE roomNum=?";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, status);   // new status
            pstmt.setInt(2, roomNum);     // room number to update
            pstmt.executeUpdate();        // execute update
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Deletes a room record from the "rooms" table
    public void deleteRoom(int roomNum) {
        String sql = "DELETE FROM rooms WHERE roomNum=?";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, roomNum);     // room number to delete
            pstmt.executeUpdate();        // execute delete
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Loads all rooms from the database into a List of Room objects
    public List<Room> loadRooms() {
        List<Room> rooms = new ArrayList<>();
        String sql = "SELECT roomNum, type, status, price FROM rooms";

        try (Connection conn = connect(); 
             Statement stmt = conn.createStatement(); 
             ResultSet rs = stmt.executeQuery(sql)) {

            // Iterate through the result set (all rows in the "rooms" table)
            while (rs.next()) {
                int num = rs.getInt("roomNum");     // room number
                String type = rs.getString("type"); // room type
                String status = rs.getString("status"); // room status
                double price = rs.getDouble("price");   // room price

                // Create the appropriate Room object based on type
                Room room;
                if (type.equalsIgnoreCase("Single")) {
                    room = new SingleRoom(num, status, price);
                } else if (type.equalsIgnoreCase("Double")) {
                    room = new DoubleRoom(num, status, price);
                } else {
                    room = new SuiteRoom(num, status, price);
                }

                // Add the room object to the list
                rooms.add(room);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Return the list of rooms loaded from the database
        return rooms;
    }
}
