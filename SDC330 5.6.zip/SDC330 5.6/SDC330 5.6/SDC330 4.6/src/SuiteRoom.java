/*Trent Jorgensen
SDC330 5.6
12/10/2025
*/

// SuiteRoom class: represents a specific type of room (Suite) in the hotel.
// It extends the abstract Room class and provides concrete implementations
// for booking and releasing the room.
public class SuiteRoom extends Room {

    // Constructor: initializes a SuiteRoom with its room number, status, and price.
    // The "type" is hardcoded as "Suite" since this class always represents suite rooms.
    public SuiteRoom(int roomNum, String status, double price) {
        // Calls the constructor of the parent class (Room) to set up the fields.
        super(roomNum, "Suite", status, price);
    }

    // Overrides the abstract method from RoomOperations.
    // When a room is booked, its status is set to "Occupied".
    @Override
    public void bookRoom() { 
        setStatus("Occupied"); 
    }

    // Overrides the abstract method from RoomOperations.
    // When a room is released, its status is set back to "Available".
    @Override
    public void releaseRoom() { 
        setStatus("Available"); 
    }
}


