/*Trent Jorgensen
SDC330 5.6
12/10/2025
*/

// Abstract class Room: serves as a blueprint for different types of rooms (Single, Double, Suite).
// It implements RoomOperations, meaning subclasses must define how to book and release a room.
public abstract class Room implements RoomOperations {
    
    // Protected fields: accessible by subclasses (SingleRoom, DoubleRoom, SuiteRoom)
    protected int roomNum;     // Unique identifier for the room
    protected String type;     // Type of room (e.g., Single, Double, Suite)
    protected String status;   // Current status (e.g., Available, Occupied)
    protected double price;    // Price per night for the room

    // Constructor: initializes a room with its number, type, status, and price
    public Room(int roomNum, String type, String status, double price) {
        this.roomNum = roomNum;
        this.type = type;
        this.status = status;
        this.price = price;
    }

    // Getter method: returns the room number
    public int getRoomNumber() {
        return roomNum;
    }

    // Returns a string with all details about the room
    // Example: "Room 101 - Single - Available - $75.0"
    public String getDetails() {
        return "Room " + roomNum + " - " + type + " - " + status + " - $" + price;
    }

    // Allows updating the status of the room (e.g., Available -> Occupied)
    public void setStatus(String status) {
        this.status = status;
    }
}



