/*Trent Jorgensen
SDC330 5.6
12/10/2025
*/

// RoomOperations interface: defines the basic operations that any room must support.
// Interfaces in Java specify a contract — any class that implements this interface
// must provide concrete implementations for the methods declared here.
public interface RoomOperations {

    // Method to book a room.
    // Implementing classes (e.g., SingleRoom, DoubleRoom, SuiteRoom) must define
    // how booking changes the room's status (usually to "Occupied").
    void bookRoom();

    // Method to release a room.
    // Implementing classes must define how releasing changes the room's status
    // (usually back to "Available").
    void releaseRoom();
}



