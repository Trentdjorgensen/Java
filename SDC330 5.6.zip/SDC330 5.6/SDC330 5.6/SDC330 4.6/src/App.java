/*Trent Jorgensen
SDC330 5.6
12/10/2025
*/

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        // Create a Scanner object to read user input from the console
        Scanner scanner = new Scanner(System.in);
        
        // Create a Hotel object with the name "The Oasis Hotel"
        Hotel hotel = new Hotel("The Oasis Hotel");
        
        // Create a DatabaseHandler object to interact with the SQLite database
        DatabaseHandler db = new DatabaseHandler();

        // Ensure the database table exists (creates it if not already created)
        db.createTable();

        // Load existing rooms from the database into the Hotel object
        hotel.setRooms(db.loadRooms());

        // Flag to keep the program running until the user chooses to exit
        boolean running = true;
        
        // Main program loop
        while (running) {
            // Display the menu options
            System.out.println("\n--- Hotel Management System ---");
            System.out.println("1. Add Room");
            System.out.println("2. View Rooms");
            System.out.println("3. Book Room");
            System.out.println("4. Release Room");
            System.out.println("5. Delete Room");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");

            // Read the user's choice
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline character left after nextInt()

            // Handle the user's choice using a switch statement
            switch (choice) {
                case 1:
                    // Add a new room
                    System.out.print("Enter room number: ");
                    int roomNum = scanner.nextInt();
                    scanner.nextLine();

                    System.out.print("Enter room type (Single/Double/Suite): ");
                    String type = scanner.nextLine();

                    System.out.print("Enter price: ");
                    double price = scanner.nextDouble();
                    scanner.nextLine();

                    // Create the appropriate Room object based on type
                    Room room;
                    if (type.equalsIgnoreCase("Single")) {
                        room = new SingleRoom(roomNum, "Available", price);
                    } else if (type.equalsIgnoreCase("Double")) {
                        room = new DoubleRoom(roomNum, "Available", price);
                    } else {
                        room = new SuiteRoom(roomNum, "Available", price);
                    }

                    // Add the room to the Hotel object (in memory)
                    hotel.addRoom(room);
                    // Save the room to the database (persistent storage)
                    db.insertRoom(room.getRoomNumber(), type, "Available", price);
                    break;

                case 2:
                    // View all rooms currently in the Hotel object
                    hotel.viewRooms();
                    break;

                case 3:
                    // Book a room (set its status to Occupied)
                    System.out.print("Enter room number to book: ");
                    int bookNum = scanner.nextInt();
                    scanner.nextLine();
                    hotel.bookRoom(bookNum);           // update in memory
                    db.updateRoom(bookNum, "Occupied"); // update in database
                    break;

                case 4:
                    // Release a room (set its status back to Available)
                    System.out.print("Enter room number to release: ");
                    int releaseNum = scanner.nextInt();
                    scanner.nextLine();
                    hotel.releaseRoom(releaseNum);       // update in memory
                    db.updateRoom(releaseNum, "Available"); // update in database
                    break;

                case 5:
                    // Delete a room completely
                    System.out.print("Enter room number to delete: ");
                    int deleteNum = scanner.nextInt();
                    scanner.nextLine();
                    hotel.deleteRoom(deleteNum); // remove from memory
                    db.deleteRoom(deleteNum);    // remove from database
                    break;

                case 6:
                    // Exit the program
                    running = false;
                    System.out.println("Exiting system...");
                    break;

                default:
                    // Handle invalid menu choices
                    System.out.println("Invalid choice. Try again.");
            }
        }

        // Close the Scanner to free resources
        scanner.close();
    }
}





