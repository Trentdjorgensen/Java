/*Trent Jorgensen
 * SDC330L 3.2
 * 11/25/2025
 */

//Create SalariedEmp Class
public class SalariedEmp extends Employee {
    private final double salary;

    public SalariedEmp(String id, String name, double salary) {//Create constructor
        super(id, name);
        this.salary = salary;
    }
    @Override
    public String getType() {
        return "Salaried";
    }
    @Override
    public void display() {
        super.display();
        System.out.println("Salary: $" + salary);
    }

    public double getSalary() {
        return salary;
    }
}

