/*Trent Jorgensen
 * SDC330L 3.2
 * 11/25/2025
 */

import java.util.*;

public class DataHandler {
    private final Map<String, Employee> employeeMap = new HashMap<>();

    public void addEmployee(Employee emp) {
        employeeMap.put(emp.getId(), emp);
    }

    public void removeEmployee(String id) {
        employeeMap.remove(id);
    }

    public void updateEmployeeName(String id, String newName) {
        Employee emp = employeeMap.get(id);
        if (emp != null) {
            emp.updateName(newName);
        }
    }

    public void displayAll() {
        for (Employee emp : employeeMap.values()) {
            emp.display();
            System.out.println();
        }
    }

    public void displayByType(String type) {
        for (Employee emp : employeeMap.values()) {
            if (emp.getType().equalsIgnoreCase(type)) {
                emp.display();
                System.out.println();
            }
        }
    }
}
