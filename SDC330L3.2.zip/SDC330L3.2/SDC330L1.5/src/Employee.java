/*Trent Jorgensen
 * SDC330L 3.2
 * 11/25/2025
 */

    //Create Employee Class
    public abstract class Employee implements Displayable {
    protected String id;
    protected String name;

    public Employee(String id, String name) {//Create constructor
        this.id = id;
        this.name = name;
    }

    public abstract String getType();

    public void updateName(String newName) {//Method to update employee's name
        this.name = newName;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public void display() {//Display employee
        System.out.println("ID: " + id + ", Name: " + name + ", Type: " + getType());
    }
}


