/*Trent Jorgensen
 * SDC330L 3.2
 * 11/25/2025
 */

//Create Commission Class
public class CommissionEmp extends Employee {
    private final double commissionRate;

    public CommissionEmp(String id, String name, double commissionRate) {//Create constructor
        super(id, name);
        this.commissionRate = commissionRate;
    }
    @Override
    public String getType() {
        return "Commission";
    }
    @Override
    public void display() {
        super.display();//Display base employee info
        System.out.println("Commission Rate: " + commissionRate + "%");
    }

    public double getCommissionRate() {//Get commission rate
        return commissionRate;
    }
}
