/*Trent Jorgensen
 * SDC330L 3.2
 * 11/25/2025
 */

public interface Displayable {
    void display();
}
