/*Trent Jorgensen
 * SDC330L 3.2
 * 11/25/2025
 */
//Create HourlyEmp Class
public class HourlyEmp extends Employee {
    private final double hourlyRate;

    public HourlyEmp(String id, String name, double hourlyRate) {//Create constructor
        super(id, name);
        this.hourlyRate = hourlyRate;
    }
    @Override
    public String getType() {
        return "Hourly";
    }
    @Override
    public void display() {
        super.display();
        System.out.println("Hourly Rate: $" + hourlyRate + "/hr");
    }

    public double getHourlyRate() {
        return hourlyRate;
    }
}
