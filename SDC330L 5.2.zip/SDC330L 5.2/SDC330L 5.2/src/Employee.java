/*Trent Jorgensen
 * SDC330L 5.2
 * 12/4/2025
 */

/**
 * Abstract class requirement: common base for all employees.
 * Demonstrates polymorphism via getType(), getValue(), and display() overrides.
 */
public abstract class Employee implements Displayable {
    protected String id;
    protected String name;

    public Employee(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public abstract String getType();
    public abstract double getValue();
    public abstract void setValue(double newValue); // allow updates

    public void updateName(String newName) {
        this.name = newName;
    }

    public String getId() { return id; }
    public String getName() { return name; }

    @Override
    public void display() {
        System.out.printf("ID: %s, Name: %s, Type: %s%n", id, name, getType());
    }
}

