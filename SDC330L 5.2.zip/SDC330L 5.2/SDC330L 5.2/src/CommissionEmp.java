/*Trent Jorgensen
 * SDC330L 5.2
 * 12/4/2025
 */

/**
 * Commission employee with a commission rate percentage.
 */
public class CommissionEmp extends Employee {
    private double commissionRate; // percent, e.g., 12.5

    public CommissionEmp(String id, String name, double commissionRate) {
        super(id, name);
        this.commissionRate = commissionRate;
    }

    @Override
    public String getType() {
        return "Commission";
    }

    @Override
    public void display() {
        super.display();
        System.out.printf("Commission Rate: %.2f%%%n", commissionRate);
    }

    @Override
    public double getValue() {
        return commissionRate;
    }

    @Override
    public void setValue(double newValue) {
        this.commissionRate = newValue;
    }
}


