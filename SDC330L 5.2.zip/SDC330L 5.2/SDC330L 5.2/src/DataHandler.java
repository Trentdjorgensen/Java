/*Trent Jorgensen
 * SDC330L 5.2
 * 12/4/2025
 */

import java.util.List;

/**
 * Composition: wraps DAO operations and provides higher-level display logic.
 * Handles UI-facing tasks and table formatting.
 */
public class DataHandler {
    private final EmployeeDAO dao;

    public DataHandler(EmployeeDAO dao) {
        this.dao = dao;
    }

    // Create/Add employee (insert or update)
    public void addEmployee(Employee emp) {
        dao.upsert(emp); // always insert or update
    }

    // Remove employee
    public void removeEmployee(String id) {
        dao.deleteById(id);
    }

    // Update employee name (insert if not exists)
    public void updateEmployeeName(String id, String newName) {
        Employee e = dao.findById(id);
        if (e == null) {
            // Default to Salaried employee if not found
            e = new SalariedEmp(id, newName, 0.0);
        } else {
            e.updateName(newName);
        }
        dao.upsert(e);
    }

    // Update employee pay type (insert if not exists)
    public void updateEmployeeValue(String id, double newValue) {
        Employee e = dao.findById(id);
        if (e == null) {
            // Default to Salaried employee if not found
            e = new SalariedEmp(id, "Unknown", newValue);
        } else {
            e.setValue(newValue);
        }
        dao.upsert(e);
    }

    // Display all employees in a table
    public void displayAll() {
        List<Employee> emps = dao.findAll();
        printTable(emps);
    }

    // Display employees by type in a table
    public void displayByType(String type) {
        List<Employee> emps = dao.findByType(type);
        printTable(emps);
    }

    // Table formatting for console
    private void printTable(List<Employee> emps) {
        System.out.printf("%-10s %-20s %-15s %-10s%n", "ID", "Name", "Type", "Value");
        System.out.println("---------------------------------------------------------------");
        for (Employee e : emps) {
            System.out.printf("%-10s %-20s %-15s %-10.2f%n",
                    e.getId(), e.getName(), e.getType(), e.getValue());
        }
        if (emps.isEmpty()) {
            System.out.println("(No employees found)");
        }
    }
}
