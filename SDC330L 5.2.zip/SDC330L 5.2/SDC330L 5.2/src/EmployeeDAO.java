/*Trent Jorgensen
 * SDC330L 5.2
 * 12/4/2025
 */

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO - (Data Access Object.)
 * DAO layer: handles all SQLite persistence via JDBC.
 * Table: employees(id TEXT PRIMARY KEY, name TEXT, type TEXT, value REAL)
 * CRUD
 */
public class EmployeeDAO {
    private final String dbPath;

    public EmployeeDAO(String dbPath) {
        this.dbPath = dbPath;
    }

    // Create table if not exists
    public void init() {
        String sql = "CREATE TABLE IF NOT EXISTS employees (" +
                     "id TEXT PRIMARY KEY," +
                     "name TEXT NOT NULL," +
                     "type TEXT NOT NULL," +
                     "value REAL NOT NULL)";
        try (Connection conn = getConnection(); Statement st = conn.createStatement()) {
            st.execute(sql);
        } catch (SQLException e) {
            System.out.println("DB init error: " + e.getMessage());
        }
    }

    // Insert employee
    public void insert(Employee e) {
        String sql = "INSERT OR REPLACE INTO employees(id, name, type, value) VALUES(?,?,?,?)";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, e.getId());
            ps.setString(2, e.getName());
            ps.setString(3, e.getType());
            ps.setDouble(4, e.getValue());
            ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Insert error: " + ex.getMessage());
        }
    }

    // Update employee
    public void upsert(Employee e) {
    String sql = "INSERT INTO employees (id, name, type, value) " +
                 "VALUES (?, ?, ?, ?) " +
                 "ON CONFLICT(id) DO UPDATE SET " +
                 "name=excluded.name, type=excluded.type, value=excluded.value";
    try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, e.getId());
        ps.setString(2, e.getName());
        ps.setString(3, e.getType());
        ps.setDouble(4, e.getValue());
        ps.executeUpdate();
    } catch (SQLException ex) {
        System.out.println("Upsert error: " + ex.getMessage());
    }
}


    // Delete by ID
    public void deleteById(String id) {
        String sql = "DELETE FROM employees WHERE id=?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Delete error: " + ex.getMessage());
        }
    }

    // Find all
    public List<Employee> findAll() {
        String sql = "SELECT id, name, type, value FROM employees ORDER BY id";
        List<Employee> list = new ArrayList<>();
        try (Connection conn = getConnection(); Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException ex) {
            System.out.println("FindAll error: " + ex.getMessage());
        }
        return list;
    }

    // Find by type 
    public List<Employee> findByType(String type) {
        String sql = "SELECT id, name, type, value FROM employees WHERE LOWER(type) = LOWER(?) ORDER BY id";
        List<Employee> list = new ArrayList<>();
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, type);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        } catch (SQLException ex) {
            System.out.println("FindByType error: " + ex.getMessage());
        }
        return list;
    }

    // Find by ID
    public Employee findById(String id) {
        String sql = "SELECT id, name, type, value FROM employees WHERE id=?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException ex) {
            System.out.println("FindById error: " + ex.getMessage());
        }
        return null;
    }

    // Map DB row to proper Employee subtype (polymorphism)
    private Employee mapRow(ResultSet rs) throws SQLException {
        String id = rs.getString("id");
        String name = rs.getString("name");
        String type = rs.getString("type");
        double value = rs.getDouble("value");

        switch (type.toLowerCase()) {
            case "salaried":
                return new SalariedEmp(id, name, value);
            case "hourly":
                return new HourlyEmp(id, name, value);
            case "commission":
                return new CommissionEmp(id, name, value);
            default:
                // Fallback (shouldn't happen if we control input)
                return new SalariedEmp(id, name, value);
        }
    }

    // Get connection to SQLite
    private Connection getConnection() throws SQLException {
        String url = "jdbc:sqlite:" + dbPath;
        return DriverManager.getConnection(url);
    }
}

