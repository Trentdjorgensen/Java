/*Trent Jorgensen
 * SDC330L 5.2
 * 12/4/2025
 */
/**
 * Interface requirement: classes implementing this can display themselves.
 */
public interface Displayable {
    void display();
}

