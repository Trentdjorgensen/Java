/*Trent Jorgensen
 * SDC330L 1.5
 * 11/13/2025
 */

    public abstract class Employee implements Displayable {
    protected String id;
    protected String name;

    public Employee(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public abstract String getType();

    public void updateName(String newName) {
        this.name = newName;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public void display() {
        System.out.println("ID: " + id + ", Name: " + name + ", Type: " + getType());
    }
}


