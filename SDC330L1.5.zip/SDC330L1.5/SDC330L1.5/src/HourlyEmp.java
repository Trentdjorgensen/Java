/*Trent Jorgensen
 * SDC330L 1.5
 * 11/13/2025
 */

public class HourlyEmp extends Employee {
    private final double hourlyRate;

    public HourlyEmp(String id, String name, double hourlyRate) {
        super(id, name);
        this.hourlyRate = hourlyRate;
    }
    @Override
    public String getType() {
        return "Hourly";
    }
    @Override
    public void display() {
        super.display();
        System.out.println("Hourly Rate: $" + hourlyRate + "/hr");
    }

    public double getHourlyRate() {
        return hourlyRate;
    }
}
