/*Trent Jorgensen
 * SDC330L 1.5
 * 11/13/2025
 */

public class CommissionEmp extends Employee {
    private final double commissionRate;

    public CommissionEmp(String id, String name, double commissionRate) {
        super(id, name);
        this.commissionRate = commissionRate;
    }
    @Override
    public String getType() {
        return "Commission";
    }
    @Override
    public void display() {
        super.display();
        System.out.println("Commission Rate: " + commissionRate + "%");
    }

    public double getCommissionRate() {
        return commissionRate;
    }
}
