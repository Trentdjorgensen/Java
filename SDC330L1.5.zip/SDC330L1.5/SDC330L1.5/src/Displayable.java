/*Trent Jorgensen
 * SDC330L 1.5
 * 11/13/2025
 */

public interface Displayable {
    void display();
}
