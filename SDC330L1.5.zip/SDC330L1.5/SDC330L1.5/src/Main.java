/*Trent Jorgensen
 * SDC330L 1.5
 * 11/13/2025
 */

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DataHandler db = new DataHandler();

        while (true) {
            System.out.println("Welcome to the Employee Management System!");
            System.out.println("\nPlease select an option below.");
            System.out.println("1. Add Employee");
            System.out.println("2. Remove Employee");
            System.out.println("3. Update Employee Name");
            System.out.println("4. Display All Employees");
            System.out.println("5. Display Employees by Type");
            System.out.println("6. Quit");
            System.out.print("Enter choice: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    System.out.print("ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Type one (Salaried/Commission/Hourly): ");
                    String type = scanner.nextLine();
                    System.out.print("Input dollar amount(Salary/Rate): ");
                    double value = Double.parseDouble(scanner.nextLine());

                    Employee emp = null;
                    switch (type.toLowerCase()) {
                        case "salaried":
                            emp = new SalariedEmp(id, name, value);
                            break;
                        case "commission":
                            emp = new CommissionEmp(id, name, value);
                            break;
                        case "hourly":
                            emp = new HourlyEmp(id, name, value);
                            break;
                        default:
                            System.out.println("Invalid type.");
                    }

                    if (emp != null) {
                        db.addEmployee(emp);
                        System.out.println("Employee added.");
                    } else {
                        System.out.println("Invalid type.");
                    }
                    break;

                case "2":
                    System.out.print("Enter ID to remove: ");
                    db.removeEmployee(scanner.nextLine());
                    System.out.println("Employee removed.");
                    break;

                case "3":
                    System.out.print("Enter ID to update: ");
                    String updateId = scanner.nextLine();
                    System.out.print("New name: ");
                    db.updateEmployeeName(updateId, scanner.nextLine());
                    System.out.println("Name updated.");
                    break;

                case "4":
                    db.displayAll();
                    break;

                case "5":
                    System.out.print("Enter type: ");
                    db.displayByType(scanner.nextLine());
                    break;

                case "6":
                    System.out.println("You are exitinng...Goodbye!");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}

