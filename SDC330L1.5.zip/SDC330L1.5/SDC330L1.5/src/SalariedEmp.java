/*Trent Jorgensen
 * SDC330L 1.5
 * 11/13/2025
 */

public class SalariedEmp extends Employee {
    private final double salary;

    public SalariedEmp(String id, String name, double salary) {
        super(id, name);
        this.salary = salary;
    }
    @Override
    public String getType() {
        return "Salaried";
    }
    @Override
    public void display() {
        super.display();
        System.out.println("Salary: $" + salary);
    }

    public double getSalary() {
        return salary;
    }
}

