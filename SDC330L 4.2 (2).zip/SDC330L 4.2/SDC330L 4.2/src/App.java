/*Trent Jorgensen
 * SDC330L 4.2
 * 12/4/2025
 */

import java.util.Scanner;

/**
 * Console UI for the Employee Management System.
 * Provides a menu-driven interface for managing employees.
 */
public class App {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Initialize DAO (database access) and DataHandler (business logic)
        EmployeeDAO dao = new EmployeeDAO("employees.db");
        dao.init(); // create table if it doesn't exist
        DataHandler db = new DataHandler(dao);

        // Main program loop: runs until user chooses to quit
        while (true) {
            // Display menu options
            System.out.println("\nTrent Jorgensen, SDC330L 4.2");
            System.out.println("\nWelcome to the Employee Management System!");
            System.out.println("1. Add Employee");
            System.out.println("2. Remove Employee");
            System.out.println("3. Update Employee Name");
            System.out.println("4. Display All Employees");
            System.out.println("5. Display Employees by Type");
            System.out.println("6. Update Employee Value (Salary/Rate/Commission)");
            System.out.println("7. Quit");
            System.out.print("Enter choice: ");

            String choice = scanner.nextLine().trim(); // read user input

            switch (choice) {
                case "1": // Add employee
                    System.out.print("ID: ");
                    String id = scanner.nextLine().trim();

                    System.out.print("Name: ");
                    String name = scanner.nextLine().trim();

                    System.out.print("Type (Salaried/Commission/Hourly): ");
                    String type = scanner.nextLine().trim().toLowerCase();

                    System.out.print("Value (Salary/Rate/Commission%): ");
                    double value;
                    try {
                        value = Double.parseDouble(scanner.nextLine().trim());
                    } catch (NumberFormatException ex) {
                        System.out.println("Invalid numeric value.");
                        break;
                    }

                    // Create appropriate employee object based on type
                    Employee emp = null;
                    switch (type) {
                        case "salaried":
                            emp = new SalariedEmp(id, name, value);
                            break;
                        case "hourly":
                            emp = new HourlyEmp(id, name, value);
                            break;
                        case "commission":
                            emp = new CommissionEmp(id, name, value);
                            break;
                        default:
                            System.out.println("Invalid type.");
                            break;
                    }

                    // Add or update employee in database
                    if (emp != null) {
                        db.addEmployee(emp);
                        System.out.println("Employee added or updated.");
                    }
                    break;

                case "2": // Remove employee
                    System.out.print("Enter ID to remove: ");
                    String remId = scanner.nextLine().trim();
                    db.removeEmployee(remId);
                    System.out.println("Employee removed (if existed).");
                    break;

                case "3": // Update employee name
                    System.out.print("Enter ID to update: ");
                    String updId = scanner.nextLine().trim();
                    System.out.print("New name: ");
                    String newName = scanner.nextLine().trim();
                    db.updateEmployeeName(updId, newName);
                    System.out.println("Name updated or new employee created.");
                    break;

                case "4": // Display all employees
                    db.displayAll();
                    break;

                case "5": // Display employees by type
                    System.out.print("Enter type (Salaried/Hourly/Commission): ");
                    String t = scanner.nextLine().trim();
                    db.displayByType(t);
                    break;

                case "6": // Update employee value
                    System.out.print("Enter ID to update value: ");
                    String valId = scanner.nextLine().trim();
                    System.out.print("New value (Salary/Rate/Commission%): ");
                    double newVal;
                    try {
                        newVal = Double.parseDouble(scanner.nextLine().trim());
                    } catch (NumberFormatException ex) {
                        System.out.println("Invalid numeric value.");
                        break;
                    }
                    db.updateEmployeeValue(valId, newVal);
                    System.out.println("Value updated or new employee created.");
                    break;

                case "7": // Quit program
                    System.out.println("Goodbye!");
                    scanner.close();
                    return;

                default: // Handle invalid menu choice
                    System.out.println("Invalid choice.");
            }
        }
    }
}

