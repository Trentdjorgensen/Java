/*Trent Jorgensen
 * SDC330L 4.2
 * 12/4/2025
 */

/**
 * Salaried employee with annual salary.
 */
public class SalariedEmp extends Employee {
    private double salary;

    public SalariedEmp(String id, String name, double salary) {
        super(id, name);
        this.salary = salary;
    }

    @Override
    public String getType() {
        return "Salaried";
    }

    @Override
    public void display() {
        super.display();
        System.out.printf("Salary: $%.2f/year%n", salary);
    }

    @Override
    public double getValue() {
        return salary;
    }

    @Override
    public void setValue(double newValue) {
        this.salary = newValue;
    }
}


