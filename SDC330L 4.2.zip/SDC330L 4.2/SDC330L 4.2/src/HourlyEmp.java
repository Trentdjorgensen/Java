/*Trent Jorgensen
 * SDC330L 4.2
 * 12/4/2025
 */

/**
 * Hourly employee with an hourly rate.
 */
public class HourlyEmp extends Employee {
    private double hourlyRate;

    public HourlyEmp(String id, String name, double hourlyRate) {
        super(id, name);
        this.hourlyRate = hourlyRate;
    }

    @Override
    public String getType() {
        return "Hourly";
    }

    @Override
    public void display() {
        super.display();
        System.out.printf("Hourly Rate: $%.2f/hr%n", hourlyRate);
    }

    @Override
    public double getValue() {
        return hourlyRate;
    }

    @Override
    public void setValue(double newValue) {
        this.hourlyRate = newValue;
    }
}

