/*Trent Jorgensen
 * SDC330L 4.2
 * 12/4/2025
 */

import java.util.Scanner;

/**
 * Console UI for the Employee Management System.
 * This program runs continuously until the user chooses to quit.
 */
public class App {
    public static void main(String[] args) {
        // Create a Scanner object to read user input from the console
        Scanner scanner = new Scanner(System.in);

        // Composition: DataHandler uses EmployeeDAO (which interacts with SQLite database)
        EmployeeDAO dao = new EmployeeDAO("employees.db"); // connect to employees.db file
        dao.init(); // initialize database (create table if it doesn't exist)
        DataHandler db = new DataHandler(dao); // wrap DAO with higher-level operations

        // Main program loop: keeps showing menu until user chooses to quit
        while (true) {
            // Display menu options
            System.out.println("\nTrent Jorgensen, SDC330L 4.2");
            System.out.println("\nWelcome to the Employee Management System!");
            System.out.println("1. Add Employee");
            System.out.println("2. Remove Employee");
            System.out.println("3. Update Employee Name");
            System.out.println("4. Display All Employees");
            System.out.println("5. Display Employees by Type");
            System.out.println("6. Update Employee Value (Salary/Rate/Commission)");
            System.out.println("7. Quit");
            System.out.print("Enter choice: ");

            // Read user choice
            String choice = scanner.nextLine().trim();

            // Handle user choice with switch statement
            switch (choice) {
                case "1": // Add new employee
                    System.out.print("ID: ");
                    String id = scanner.nextLine().trim();

                    System.out.print("Name: ");
                    String name = scanner.nextLine().trim();

                    System.out.print("Type (Salaried/Commission/Hourly): ");
                    String type = scanner.nextLine().trim().toLowerCase();

                    System.out.print("Value (Salary/Rate/Commission%): ");
                    double value;
                    try {
                        // Parse numeric input for salary/hourly rate/commission
                        value = Double.parseDouble(scanner.nextLine().trim());
                    } catch (NumberFormatException ex) {
                        System.out.println("Invalid numeric value.");
                        break;
                    }

                    // Create appropriate Employee object based on type
                    Employee emp = null;
                    switch (type) {
                        case "salaried":
                            emp = new SalariedEmp(id, name, value);
                            break;
                        case "hourly":
                            emp = new HourlyEmp(id, name, value);
                            break;
                        case "commission":
                            emp = new CommissionEmp(id, name, value);
                            break;
                        default:
                            System.out.println("Invalid type.");
                            break;
                    }

                    // If employee was created successfully, add to database
                    if (emp != null) {
                        db.addEmployee(emp);
                        System.out.println("Employee added.");
                    }
                    break;

                case "2": // Remove employee by ID
                    System.out.print("Enter ID to remove: ");
                    String remId = scanner.nextLine().trim();
                    db.removeEmployee(remId);
                    System.out.println("Employee removed (if existed).");
                    break;

                case "3": // Update employee name
                    System.out.print("Enter ID to update: ");
                    String updId = scanner.nextLine().trim();
                    System.out.print("New name: ");
                    String newName = scanner.nextLine().trim();
                    db.updateEmployeeName(updId, newName);
                    System.out.println("Name updated (if employee exists).");
                    break;

                case "4": // Display all employees
                    db.displayAll();
                    break;

                case "5": // Display employees filtered by type
                    System.out.print("Enter type (Salaried/Hourly/Commission): ");
                    String t = scanner.nextLine().trim();
                    db.displayByType(t);
                    break;

                case "6": // Update numeric value (salary/hourly rate/commission)
                    System.out.print("Enter ID to update value: ");
                    String valId = scanner.nextLine().trim();
                    System.out.print("New value (Salary/Rate/Commission%): ");
                    double newVal;
                    try {
                        newVal = Double.parseDouble(scanner.nextLine().trim());
                    } catch (NumberFormatException ex) {
                        System.out.println("Invalid numeric value.");
                        break;
                    }
                    db.updateEmployeeValue(valId, newVal);
                    System.out.println("Value updated (if employee exists).");
                    break;

                case "7": // Quit program
                    System.out.println("Goodbye!");
                    scanner.close(); // close scanner resource
                    return; // exit program

                default: // Handle invalid menu choice
                    System.out.println("Invalid choice.");
            }
        }
    }
}
